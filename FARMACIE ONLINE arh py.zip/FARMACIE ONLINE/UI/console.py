from SERVICE.medicament_service import MedicamentService
from SERVICE.card_client_service import Card_client_Service
from SERVICE.tranzactie_service import Tranzactie_Service
from SERVICE.sortari_service import SortariService
from datetime import datetime
from SERVICE.undo_redo_service import UndoRedoService

class Console:

    def __init__(self,
                 medicament_service: MedicamentService,
                 card_client_service: Card_client_Service,
                 tranzactie_service: Tranzactie_Service,
                 sortari_service: SortariService,
                 undo_redo_service:UndoRedoService):
        self.__medicament_service = medicament_service
        self.__card_client_service = card_client_service
        self.__tranzactie_service = tranzactie_service
        self.__sortari_service= sortari_service
        self.__undo_redo_service = undo_redo_service

    def print_menu(self):
        print('1. CRUD Medicamente')
        print('2. CRUD Carduri_clienti')
        print('3. CRUD Tranzactii')
        print('4. Căutare medicamente și clienți după nume, producător, prenume, CNP etc.')
        print('5. Afisarea tuturor tranzactiilor dintr-un interval de zile dat.')
        print('6. Afișarea medicamentelor ordonate descrescător după numărul de vânzări.')
        print('7. Afișarea cardurilor client ordonate descrescător după valoarea reducerilor obținute.')
        print('8. Ștergerea tuturor tranzacțiilor dintr-un anumit interval de zile.')
        print('9. Scumpirea cu un procentaj dat al unui medicament cu pretul mai mic decat o valoare data.')
        print('10. Genereaza n entitati cu campurile completate random.')
        print('11. Export')
        print('12. Implementați o sortare proprie, cu aceeași interfață cu funcția sorted din Python.')
        print('13. Afisarea tuturor tranzactiilor dintr-un interval de zile dat.(varianta cu filtru)')
        print('14. QUICKSORT')
        print('u. UNDO')
        print('r. REDO')
        print('x. Iesire')

    def run_console(self):

        while True:
            self.print_menu()
            option = input('Alegeti optiunea: ')
            if option == '1':
                self.run_crud_medicamente()
            elif option == '2':
                self.run_crud_carduri_clienti()
            elif option == '3':
                self.run_crud_tranzactii()
            elif option == '4':
                self.ui_cautare_full_text()
            elif option == '5':
                self.ui_afisare_tranzactii_din_interval()
            elif option == '6':
                self.ui_ordoneaza_medicamente_dupa_vanzari()
            elif option =='7':
                self.ui_ordoneaza_carduri_dupa_reducere()
            elif option == '8':
                self.ui_sterge_tranzactii_din_interval()
            elif option == '9':
                self.ui_scumpire_medicament()
            elif option == '10':
                self.ui_populate_entities()
            elif option == '11':
                self.ui_export()
            elif option == '12':
                self.ui_sortare_proprie()
            elif option == '13':
                self.ui_afisare_tranzactii_din_interval_filtru()
            elif option == '14':
                self.ui_quicksort()
            elif option == 'u':
                self.__undo_redo_service.do_undo()
            elif option == 'r':
                self.__undo_redo_service.do_redo()
            elif option == 'x':
                break
            else:
                print('Comanda invalida!')

    def run_crud_medicamente(self):
        while True:
            print('1. Adauga medicament.')
            print('2. Sterge medicament.')
            print('3. Modifica medicament.')
            print('a. Afiseaza toate medicamentele.')
            print('b. Back')
            option = input('Alegeti optiunea: ')
            if option == '1':
                self.ui_adauga_medicament()
            elif option == '2':
                self.ui_sterge_medicament()
            elif option == '3':
                self.ui_modifica_medicament()
            elif option == 'a':
                self.ui_afiseaza_toate_medicamentele_rec()
            elif option == 'b':
                break
            else:
                print('Optiune invalida.')

    def ui_adauga_medicament(self):
        try:
            id_medicament = input('ID-ul medicamentului: ')
            nume = input('Numele medicamentului: ')
            producator = input('Numele producatorului: ')
            pret = float(input('Pret: '))
            necesita_reteta = input('Necesita reteta(da/nu): ')

            self.__medicament_service.adauga(id_medicament, nume, producator, pret, necesita_reteta)

            print('Medicamentul a fost adaugat cu succes!')
        except ValueError as ve:
            print(ve)
        except KeyError as ke:
            print(ke)
        except Exception as e:
            print(e)

    def ui_afiseaza_toate_medicamentele_rec(self):
        medicamente=self.__medicament_service.get_all()
        toate_medicamentele=self.__medicament_service.afisare_rec(medicamente)
        for i in toate_medicamentele:
            print(i)

    def ui_sterge_medicament(self):
        try:
            id_medicament = input('ID-ul medicamentului care se va sterge: ')
            self.__medicament_service.sterge(id_medicament)
            tranzactii=self.__tranzactie_service.get_all()
            for tranzactie in tranzactii:
                if id_medicament==tranzactie.id_medicament:
                    self.__tranzactie_service.sterge(tranzactie.id_tranzactie)
            print('Medicamentul a fost stears!')
        except KeyError as ke:
            print(ke)

    def ui_modifica_medicament(self):
        try:
            id_medicament = input('ID-ul medicamentului: ')
            nume = input('Noul nume al medicamentului (gol pt a nu schimba): ')
            producator = input('Noul producator al medicamentului (gol pt a nu schimba): ')
            pret = float(input('Noul pret al medicamentului (0 pt a nu schimba): '))
            necesita_reteta = input('Necesita reteta(da/nu) (gol pt a nu schimba): ')

            self.__medicament_service.modifica(id_medicament,nume, producator, pret, necesita_reteta)

            print('Medicamentul a fost modificat cu succes!')
        except ValueError as ve:
            print(ve)
        except KeyError as ke:
            print(ke)
        except Exception as e:
            print(e)

    def ui_scumpire_medicament(self):
        try:
            procent=int(input('Dati procentul: ' ))
            val_data=float(input('Dati o valoare reala: '))

            self.__medicament_service.scumpire(procent,val_data)

            print('Medicamentul a fost scumpit cu succes!')
        except ValueError as ve:
            print(ve)
        except Exception as e:
            print(e)

    def ui_populate_entities(self):
        n=int(input('Dati o valoare intreaga: '))
        self.__medicament_service.populate_entities(n)

    def run_crud_carduri_clienti(self):
        while True:
            print('1. Adauga card client.')
            print('2. Sterge card client.')
            print('3. Modifica card client.')
            print('a. Afiseaza cardurile clientilor.')
            print('b. Back')
            option = input('Alegeti optiunea: ')
            if option == '1':
                self.ui_adauga_card_client()
            elif option == '2':
                self.ui_sterge_card_client()
            elif option == '3':
                self.ui_modifica_card_client()
            elif option == 'a':
                self.ui_afiseaza_toate_cardurile_clientilor()
            elif option == 'b':
                break
            else:
                print('Optiune invalida.')

    def ui_adauga_card_client(self):
        try:
            id_card_client = input('ID-ul cardului: ')
            nume = input('Numele beneficiarului cardului: ')
            prenume = input('Prenumele beneficiarului cardului: ')
            cnp=input('CNP-ul beneficiarului: ')
            data_nasterii_str = input('Data nasterii(dd.mm.yyyy): ')
            data_nasterii=datetime.strptime(data_nasterii_str,"%d.%m.%Y")
            data_inregistrarii_str = input('Data data inregistrarii(dd.mm.yyyy): ')
            data_inregistrarii = datetime.strptime(data_inregistrarii_str, "%d.%m.%Y")
            self.__card_client_service.adauga(id_card_client, nume, prenume, cnp, data_nasterii, data_inregistrarii)

            print('Card de client adaugat cu succes!')
        except ValueError as ve:
            print(ve)
        except KeyError as ke:
            print(ke)
        except Exception as e:
            print(e)

    def ui_sterge_card_client(self):
        try:
            id_card_client = input('ID-ul cardului care se va sterge: ')
            self.__card_client_service.sterge(id_card_client)
            print('Cardul a fost stears!')
        except KeyError as ke:
            print(ke)

    def ui_modifica_card_client(self):
        try:
            id_card_client = input('ID-ul cardului clientului: ')
            nume = input('Noul nume al beneficiarului (gol pt a nu schimba): ')
            prenume = input('Noul prenume al beneficiarului (gol pt a nu schimba): ')
            cnp = input('Noul cnp al beneficiarului (gol pt a nu schimba): ')
            data_nasterii_str = input('Noua data de nastere (gol pt a nu schimba): ')
            if data_nasterii_str != '':
                data_nasterii = datetime.strptime(data_nasterii_str, "%d.%m.%Y")
            else:
                data_nasterii= ''
            data_inregistrarii_str=input('Noua data de inregistrare (gol pt a nu schimba): ')
            if data_inregistrarii_str != '':
                data_inregistrarii = datetime.strptime(data_inregistrarii_str, "%d.%m.%Y")
            else:
                data_inregistrarii = ''

            self.__card_client_service.modifica(id_card_client,nume,prenume,cnp,data_nasterii,data_inregistrarii)

            print('Cardul a fost modificat cu succes!')
        except ValueError as ve:
            print(ve)
        except KeyError as ke:
            print(ke)
        except Exception as e:
            print(e)

    def ui_afiseaza_toate_cardurile_clientilor(self):
        for card_client in self.__card_client_service.get_all():
            print(card_client)

    def run_crud_tranzactii(self):
        while True:
            print('1. Adauga tranzactie.')
            print('2. Sterge tranzactie.')
            print('3. Modifica tranzactie.')
            print('a. Afiseaza toate tranzactiile.')
            print('b. Back')
            option = input('Alegeti optiunea: ')
            if option == '1':
                self.ui_adauga_tranzactie()
            elif option == '2':
                self.ui_sterge_tranzactie()
            elif option == '3':
                self.ui_modifica_tranzactie()
            elif option == 'a':
                self.ui_afiseaza_toate_tranzactiile()
            elif option == 'b':
                break
            else:
                print('Optiune invalida.')

    def ui_adauga_tranzactie(self):
        try:
            id_tranzactie = input('ID-ul tranzactiei: ')
            id_medicament = input('ID-ul medicamentului: ')
            id_card = input('ID_ul cardului de client sau 0 daca nu exista: ')
            nr_bucati = int(input('Numarul de bucati: '))
            data_ora_str= input('Data si ora tranzactiei(dd.mm.yyyy h:m): ')
            data_ora = datetime.strptime(data_ora_str, "%d.%m.%Y %H:%M")
            self.__tranzactie_service.adauga(id_tranzactie,id_medicament,id_card,nr_bucati,data_ora)

            print('Tranzactie adaugata cu succes!')
        except ValueError as ve:
            print(ve)
        except KeyError as ke:
            print(ke)
        except Exception as e:
            print(e)

    def ui_sterge_tranzactie(self):
        try:
            id_tranzactie = input('ID-ul tranzactiei care se va sterge: ')
            self.__tranzactie_service.sterge(id_tranzactie)
            print('Tranzactia a fost stearsa!')
        except KeyError as ke:
            print(ke)

    def ui_modifica_tranzactie(self):
        try:
            id_tranzactie = input('ID-ul tranzactiei: ')
            id_medicament= input('Noul id al medicamentului (gol pt a nu schimba): ')
            id_card = input('Noul id al cardului (gol pt a nu schimba): ')
            nr_bucati= input('Noul numar de bucati (gol pt a nu schimba): ')
            data_ora_str = input('Noua data si ora (dd.mm.yyyy h:m) (gol pt a nu schimba): ')
            if data_ora_str!= '':
                data_ora = datetime.strptime(data_ora_str, "%d.%m.%Y %H:%M")
            else:
                data_ora= ''

            self.__tranzactie_service.modifica(id_tranzactie,id_medicament,id_card,nr_bucati,data_ora)

            print('Tranzactie modificata cu succes!')
        except ValueError as ve:
            print(ve)
        except KeyError as ke:
            print(ke)
        except Exception as e:
            print(e)

    def ui_afiseaza_toate_tranzactiile(self):
        for tranzactie in self.__tranzactie_service.get_all():
            print(tranzactie)

    def ui_afisare_tranzactii_din_interval(self):
        try:
            interval=input('Dati zilele (sub forma 01,02,...,30,31) despartite prin virgula: ')
            interval=interval.split(',')
            ziuap=interval[0]
            ziuau=interval[1]
            tranzactii_din_interval=self.__tranzactie_service.afisare_tranzactii_din_interval(ziuap,ziuau)
            for i in range(len(tranzactii_din_interval)):
                for tranzactie in self.__tranzactie_service.get_all():
                    if tranzactie==tranzactii_din_interval[i]:
                        print(tranzactie)
        except ValueError as ve:
            print(ve)
        except Exception as e:
            print(e)

    def ui_sterge_tranzactii_din_interval(self):
        try:
            interval = input('Dati zilele (sub forma 01,02,...,30,31) despartite prin virgula: ')
            interval = interval.split(',')
            ziuap = interval[0]
            ziuau = interval[1]
            self.__tranzactie_service.sterge_tranzactii_din_interval(ziuap,ziuau)
            print('Tranzactii sterse cu succes!')
        except ValueError as ve:
            print(ve)
        except Exception as e:
            print(e)

    def ui_ordoneaza_medicamente_dupa_vanzari(self):
        rezultat=self.__tranzactie_service.ordonare_medicamente_dupa_nr_vanzari()
        for i in rezultat:
            print("Medicamentul {} cu numarul de bucati vandute egal cu {}".format(self.__medicament_service.get_by_id(i[0]),i[1]))

    def ui_ordoneaza_carduri_dupa_reducere(self):
        rezultat=self.__tranzactie_service.ordonare_carduri_dupa_reducerere()
        for i in rezultat:
            print("Cardul {} cu reducerea totala egala cu {}".format(self.__card_client_service.get_by_id(i[0]),i[1]))

    def ui_cautare_full_text(self):
        sir=input('Dati de cautat: ')
        lista=[]
        lista=self.__medicament_service.cautare(sir)
        lista=lista+self.__card_client_service.cautare(sir)
        for i in lista:
            print(i)

    def ui_export(self):
        self.__medicament_service.export()
        print('Exportul a fost efectuat!')

    def ui_sortare_proprie(self):
        medicamente=self.__medicament_service.get_all()
        lista_sortata=self.__sortari_service.interschimbari_sort(medicamente,reverse=True,key= lambda medicament:medicament.pret)
        for medicament in lista_sortata:
            print(medicament)

    def ui_afisare_tranzactii_din_interval_filtru(self):
        try:
            interval=input('Dati zilele (sub forma 01,02,...,30,31) despartite prin virgula: ')
            interval=interval.split(',')
            ziuap=interval[0]
            ziuau=interval[1]
            tranzactii_din_interval=self.__tranzactie_service.afisare_tranzactii_din_interval(ziuap,ziuau)
            for i in range(len(tranzactii_din_interval)):
                for tranzactie in self.__tranzactie_service.get_all():
                    if tranzactie==tranzactii_din_interval[i]:
                        print(tranzactie)
        except ValueError as ve:
            print(ve)
        except Exception as e:
            print(e)

    def ui_quicksort(self):
        rezultat=self.__tranzactie_service.ordonare_medicamente_quicksort()
        for i in rezultat:
            print("Medicamentul {} cu numarul de bucati vandute egal cu {}".format(i[0], i[1]))







