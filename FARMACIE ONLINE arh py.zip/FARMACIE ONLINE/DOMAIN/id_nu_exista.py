class id_nu_exista(Exception):
    pass