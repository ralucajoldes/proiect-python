class id_nu_este_unic(Exception):
    pass