def clear_file(filename):
    with open(filename, 'w'):
        pass